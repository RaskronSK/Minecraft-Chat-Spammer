  _____  ______          _____  __  __ ______ 
 |  __ \|  ____|   /\   |  __ \|  \/  |  ____|
 | |__) | |__     /  \  | |  | | \  / | |__   
 |  _  /|  __|   / /\ \ | |  | | |\/| |  __|  
 | | \ \| |____ / ____ \| |__| | |  | | |____ 
 |_|  \_\______/_/    \_\_____/|_|  |_|______|
                                            
Hello! This is my Minecraft Spammer and PLEASE Dont use this in an unintended way. Just know that if you use this on a public server if you are not allowed to, Because if you do you might face a Mute or even a BAN!!!!!!!
So please be careful with this tool

 __          _______ _   _ _____   ______          _______   _______ _    _ _______ ____  _____  _____          _      
 \ \        / /_   _| \ | |  __ \ / __ \ \        / / ____| |__   __| |  | |__   __/ __ \|  __ \|_   _|   /\   | |     
  \ \  /\  / /  | | |  \| | |  | | |  | \ \  /\  / / (___      | |  | |  | |  | | | |  | | |__) | | |    /  \  | |     
   \ \/  \/ /   | | | . ` | |  | | |  | |\ \/  \/ / \___ \     | |  | |  | |  | | | |  | |  _  /  | |   / /\ \ | |     
    \  /\  /   _| |_| |\  | |__| | |__| | \  /\  /  ____) |    | |  | |__| |  | | | |__| | | \ \ _| |_ / ____ \| |____ 
     \/  \/   |_____|_| \_|_____/ \____/   \/  \/  |_____/     |_|   \____/   |_|  \____/|_|  \_\_____/_/    \_\______|

So firstly install Python, if you dont know how to go to the Microsoft Store and search Python and make sure to download the newest version.
Then open the Command prompt and type: pip install keyboard
Great! Now you're almost ready to go. Just open up the "Start Spamming!" File and write the message that you want to spam, then just press F7 to start the spammer (Make sure to be in Minecraft while running the spammer)

  _      _____ _   _ _    ___   __  _______ _    _ _______ ____  _____  _____          _      
 | |    |_   _| \ | | |  | \ \ / / |__   __| |  | |__   __/ __ \|  __ \|_   _|   /\   | |     
 | |      | | |  \| | |  | |\ V /     | |  | |  | |  | | | |  | | |__) | | |    /  \  | |     
 | |      | | | . ` | |  | | > <      | |  | |  | |  | | | |  | |  _  /  | |   / /\ \ | |     
 | |____ _| |_| |\  | |__| |/ . \     | |  | |__| |  | | | |__| | | \ \ _| |_ / ____ \| |____ 
 |______|_____|_| \_|\____//_/ \_\    |_|   \____/   |_|  \____/|_|  \_\_____/_/    \_\______|
                                                                                              
On Linux its a LOT Easier. Dont worry in every single Distro it's the same, so open the Terminal and write: sudo apt install python3
Then open the Terminal and write: pip install keyboard
And if that didnt work try: sudo pip install keyboard
Now just open the "Start Spamming!" File write in the message you wanna spam go into Minecraft and press F7
BYEE!